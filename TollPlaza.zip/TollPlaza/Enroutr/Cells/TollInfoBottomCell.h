//
//  TollInfoBottomCell.h
//  TollPlaza
//
//  Created by Ravi Rajan on 4/15/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TollInfoBottomCell : UITableViewCell

-(void)updateDataWithInfo :(NSDictionary*)tollDetailInfo;

@end
