//
//  StaticPageViewController.h
//  TollPlaza
//
//  Created by Ravi Rajan on 3/12/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StaticPageViewController : UIViewController
@property (weak, nonatomic)  NSString *contentType;
@end
