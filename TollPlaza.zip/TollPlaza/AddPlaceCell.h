//
//  AddPlaceCell.h
//  TollPlaza
//
//  Created by Ravi Rajan on 4/13/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddPlaceCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *placeLbl;
@property (weak, nonatomic) IBOutlet UIButton *removePlaceBtn;

@end
