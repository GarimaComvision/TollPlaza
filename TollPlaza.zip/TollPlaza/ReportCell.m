//
//  ReportCell.m
//  TollPlaza
//
//  Created by Comvision on 27/06/17.
//  Copyright © 2017 Harendra. All rights reserved.
//

#import "ReportCell.h"


@interface ReportCell ()


@end

@implementation ReportCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
