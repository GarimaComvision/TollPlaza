//
//  ResetPinController.h
//  TollPlaza
//
//  Created by Ravi Rajan on 3/26/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResetPinController : UIViewController

@end
