//
//  SideTableViewCell.m

//
//  Created by Ravi Rajan on 7/25/16.
//  Copyright © 2016 dmondo. All rights reserved.
//

#import "SideTableViewCell.h"

@implementation SideTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
