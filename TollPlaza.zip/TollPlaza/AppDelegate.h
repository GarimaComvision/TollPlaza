//
//  AppDelegate.h
//  TollPlaza
//
//  Created by Ravi Rajan on 12/24/16.
//  Copyright © 2016 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

