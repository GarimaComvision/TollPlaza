//
//  TollInfoTableCell.m
//  TollPlaza
//
//  Created by Ravi Rajan on 4/15/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import "TollInfoTableCell.h"

@implementation TollInfoTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
