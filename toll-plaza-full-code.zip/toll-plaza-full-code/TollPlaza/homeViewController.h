//
//  homeViewController.h
//  TollPlaza
//
//  Created by Ravi Rajan on 2/22/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface homeViewController : UIViewController
@property (weak, nonatomic)  NSString*stringType;
@end
