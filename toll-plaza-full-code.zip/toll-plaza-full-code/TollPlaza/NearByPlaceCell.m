//
//  NearByPlaceCell.m
//  SwiftTest
//
//  Created by canvasm on 2/20/17.
//  Copyright © 2017 canvasm. All rights reserved.
//

#import "NearByPlaceCell.h"

@implementation NearByPlaceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
