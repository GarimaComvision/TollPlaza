//
//  SidebarTableViewController.h

//
//  Created by Ravi Rajan on 7/25/16.
//  Copyright © 2016 dmondo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SidebarTableViewController : UIViewController
@property (nonatomic, strong) NSString* string_header;
@property (nonatomic, strong) NSString* string_URL;


@end
