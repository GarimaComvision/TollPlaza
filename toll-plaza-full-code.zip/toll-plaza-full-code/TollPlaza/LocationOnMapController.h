//
//  LocationOnMapController.h
//  TollPlaza
//
//  Created by Comvision on 19/06/17.
//  Copyright © 2017 Harendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>

@interface LocationOnMapController : UIViewController
@property (strong)NSString *typeofIssue1;
@property (nonatomic)CLLocationCoordinate2D customlocation1;
@end
