//
//  RegisterProfileController.h
//  TollPlaza
//
//  Created by Ravi Rajan on 3/12/17.
//  Copyright © 2017 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterProfileController : UIViewController
@property (strong) NSString *profileMode;

@end
