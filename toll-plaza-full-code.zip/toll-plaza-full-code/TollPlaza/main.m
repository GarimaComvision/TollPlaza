//
//  main.m
//  TollPlaza
//
//  Created by Ravi Rajan on 12/24/16.
//  Copyright © 2016 Ravi Rajan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
